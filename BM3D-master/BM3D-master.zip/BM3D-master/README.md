# BM3D
BM3D implementation using openCV

First time I share my own writing code.

Very easy to use,start a new project on Windows visual studio,make sure the openCV is configured correctly.Then run main.cpp it takes about 3 minutes to see the result.

Though the speed is much faster than most matlab version(no MEX file included),I still think it too slow.Is there a way to accelerate?It seems that my coding is poor.Willing to hear any advice.
